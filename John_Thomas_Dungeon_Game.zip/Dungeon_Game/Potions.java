package Dungeon_Game;

import java.util.*;

public abstract class Potions
{
    protected int potionType;
    protected int healVal;
    protected int damageVal;

    public Potions(int potionTypeIN, int healValIN, int damageValIN)
    {
	potionType = potionTypeIN;
	healVal    = healValIN;
	damageVal  = damageValIN;
    }
    
    public void usePotion(HeroCharacter hero) throws InterruptedException
    {
	switch(potionType)
	    {
	    case 1: hero.getHealed(healVal);
		break;
	    case 2:
		System.out.println("The potion has soured!");
		hero.takeDamage(healVal);
		break;
	    case 3: hero.additionalDamage(damageVal);
		    break;
	    }
	return;
	    
    }


}
