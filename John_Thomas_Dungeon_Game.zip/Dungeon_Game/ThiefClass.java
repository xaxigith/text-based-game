package Dungeon_Game;

import java.util.*;

public class ThiefClass extends HeroCharacter
{
    private int NUMBER_OF_SPECIAL_ATTACKS = 1;
    public ThiefClass(String NAME_IN)
    {
	super(NAME_IN, 75, 40, 20, 0.8, 6, 0.4, 0.4);
	      //name, hp, max dam, min dam, chance to hit, attack speed, block percentage, chance to use special skill
	      }
    /*
    @Override    
    public int Attack()
    {
	int DamageDone = 0;
	if(super.SuccessfulHit())
	    {
		if(super.specialSkill())
		    {
			DamageDone = attack();	
		    }
		else
		    {
			DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			System.out.println(super.getName() + " hit for " + DamageDone + " damage!");
		    }
	    }
	else
	    System.out.println(super.getName() + " missed!!");

	return DamageDone;
    }

    public int attack()
    {
	int DamageDone, extraDamage;
	DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
	System.out.println(super.getName() + " hit for " + DamageDone + " damage");
	extraDamage = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
	System.out.println(super.getName() + " got a surpirse hit! " + super.getName() + " hit for " + extraDamage + " extra damage!");
	DamageDone += extraDamage;
	return DamageDone;
	}*/

    @Override
    public int Attack() throws InterruptedException
    {
	Scanner scan = new Scanner(System.in);
	System.out.println("It is your turn! What would you like to do? \n 1 for normal attack. \n 2 for encounter attack. ");
	int choice = Integer.parseInt(scan.nextLine());
	int used_special_attack = 0;

	int DamageDone = 0;
	if(super.SuccessfulHit())
	    {
		if(choice == 1)
		    {
			DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			System.out.println(super.getName() + " hit for " + DamageDone + " damage");
			Thread.sleep(500);

		    }
		if(choice == 2 && NUMBER_OF_SPECIAL_ATTACKS > 0)
		    {
			DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			DamageDone += (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			System.out.println(super.getName() + " hit twice! "+ super.getName() + " hit for " + DamageDone + " damage");
			Thread.sleep(500);
		    }
		if(choice == 2 && NUMBER_OF_SPECIAL_ATTACKS == 0)
		    {
			System.out.println("You are too tired to use your encounter power! You use your regular attack instead.");
			DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			System.out.println(super.getName() + " hit for " + DamageDone + " damage");
			Thread.sleep(500);
		    }
	    }
	else
	    {
		System.out.println(super.getName() + " missed!!");
		Thread.sleep(500);

	    }

	if(used_special_attack > 0)
	    {
		NUMBER_OF_SPECIAL_ATTACKS--;
		used_special_attack = 0;
	    }
	return DamageDone;
    }
    @Override
    public void resetSpecialAttack()
    {
	NUMBER_OF_SPECIAL_ATTACKS = 1;
    }

    
}
			      
