package Dungeon_Game;

import java.util.*;

public abstract class misc
{
    public static int generateRandomInt(int max, int min)
    {
	Random rand = new Random();
	return rand.nextInt( (max - min) + 1 ) + min;
    }

}
