package Dungeon_Game;

import java.util.*;

public class PaladinClass extends HeroCharacter implements Comparable
{
    public PaladinClass(String NAME_IN)
    {
	super(NAME_IN, 200, 70, 35, 0.7, 5, 0.3, 0.5);
    }
    
    public int Attack(Object obj)
    {
	int DamageDone = 0;
	if(super.SuccessfulHit())
	    {
		if( compareTo(obj) == 1 && super.specialSkill() )
		    {
			DamageDone = HolyAttack();
			System.out.println(super.getName() + " hit for "
					   + DamageDone + " damage");
		    }
		else
		    {
			DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			System.out.println(super.getName() + " hit for "
					   + DamageDone + " damage");
		    }
	    }
	else
	    System.out.println(super.getName() + " missed!!");

	return DamageDone;
    }

    public int HolyAttack()
    {
	return misc.generateRandomInt(125, 75);
    }

    public int compareTo(Object obj)
    {
	if(Skeleton.class.isInstance(obj))
	    return 1;
	else
	    return 0;

	 
    }
}//end class
