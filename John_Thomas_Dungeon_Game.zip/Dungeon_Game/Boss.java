package Dungeon_Game;

import java.util.*;

public class Boss extends Monster
{
    public Boss()
    {
	super("The Lord Maniac", 1000, 300, 50, 0.3, 1, 0.3, 150, 50);
	//super(name, hp, max dam, min dam, hit chance, attack speed, chance to heal, max heal, min heal
    }
}
