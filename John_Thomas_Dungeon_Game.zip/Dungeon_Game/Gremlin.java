package Dungeon_Game;

import java.util.*;

public class Gremlin extends Monster
{
    public Gremlin()
    {
	super("Gremlin", 150, 30, 15, 0.8, 5, 0.4, 40, 20);
        //super(name, hp, max dam, min dam, hit chance, attack speed, chance to heal, max heal, min heal
    }
}


