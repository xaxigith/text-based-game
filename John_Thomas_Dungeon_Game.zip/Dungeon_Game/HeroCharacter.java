package Dungeon_Game;

import java.util.*;

public abstract class HeroCharacter extends DungeonCharacter
{

    double CHANCE_TO_BLOCK; //percentage chance to block
    private int CHANCE_TO_BLOCK_INT;
    private int specialAttackPercentageInt;


    public HeroCharacter(String NAME_IN, int HP_IN, int DAM_MAX_IN, int DAM_MIN_IN, double CHANCE_TO_HIT_IN, int ATTACK_SPEED_IN,
			 double CHANCE_TO_BLOCK_IN, double specialAttackPercentage)
    {
	super(NAME_IN, HP_IN, DAM_MAX_IN, DAM_MIN_IN, CHANCE_TO_HIT_IN, ATTACK_SPEED_IN);
	
	CHANCE_TO_BLOCK = CHANCE_TO_BLOCK_IN;
	
	CHANCE_TO_BLOCK_INT = (int) (super.getDieSides() * CHANCE_TO_BLOCK);

	specialAttackPercentageInt = (int) (specialAttackPercentage * super.getDieSides());
    }//end constructor
       

    @Override
    public void takeDamage(int DamageIN) throws InterruptedException
    {
	int dieRoll = misc.generateRandomInt(super.getDieSides(), 1);
	if(DamageIN == 0)
	    {
		return;
	    }
	
	if(dieRoll <= CHANCE_TO_BLOCK_INT)
	    {
		System.out.println(super.getName() + " has blocked the hit!");
		Thread.sleep(500);
	    }
	else
	    {
		System.out.println(super.getName() + " has been hit");
		super.takeDamage(DamageIN);
	    }
    }//end takeDamage
    
   public boolean specialSkill()
    {
	int diceRoll = misc.generateRandomInt(super.getDieSides(), 1);

	if(diceRoll <= specialAttackPercentageInt)
	    return true;
	else
	    return false;
		
    }

    public void resetSpecialAttack()
    {

    }
    
}//end class
