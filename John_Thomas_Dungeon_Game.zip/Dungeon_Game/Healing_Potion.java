package Dungeon_Game;

import java.util.*;

public class Healing_Potion extends Potions
{
    public Healing_Potion()
    {
	super(1, 100, 0);
    }

    public void sour()
    {
	super.potionType = 2;
    }

}
