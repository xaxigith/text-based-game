package Dungeon_Game;

import java.util.*;

public class Ogre extends Monster
{
    public Ogre()
    {
	super("Ogre", 300, 60, 30, 0.6, 2, 0.1, 60, 30);
	//super(name, hp, max dam, min dam, hit chance, attack speed, chance to heal, max heal, min heal
    }
}











