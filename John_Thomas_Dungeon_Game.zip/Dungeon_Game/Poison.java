package Dungeon_Game;

import java.util.*;

public class Poison extends Potions
{
    public Poison()
    {
	super(3, 0, 100);
    }
}
