package Dungeon_Game;

/* This is the abstract DungeonCharacter super class */

import java.util.*;

public abstract class DungeonCharacter
{
    private String name;
    private int    maxHp;
    private int    DAMAGE_TAKEN = 0;
    private int    MAX_DAMAGE;
    private int    MIN_DAMAGE;
    private double CHANCE_TO_HIT;
    private int    DIE_SIDES = 10;
    private int    ATTACK_SPEED; 
    protected int  addDamage;
    
    public DungeonCharacter(String NAME_IN, int HP_IN,
			    int MAX_DAMAGE_IN, int MIN_DAMAGE_IN,
			    double CHANCE_TO_HIT_IN,
			    int ATTACK_SPEED_IN)
    {
	//super constructor
	name          = NAME_IN;
	maxHp         = HP_IN;
	MAX_DAMAGE    = MAX_DAMAGE_IN;
	MIN_DAMAGE    = MIN_DAMAGE_IN;
	CHANCE_TO_HIT = CHANCE_TO_HIT_IN*10;
	ATTACK_SPEED  = ATTACK_SPEED_IN;
    }

    public int getAttackSpeed()
    {
	return ATTACK_SPEED;
    }
    
    public int getMaxDamage()
    {
	return MAX_DAMAGE;
    }
    
    public int getMinDamage()
    {
	return MIN_DAMAGE;
    }
    
    
    public String getName()
    {
	return name;
    }

    public void takeDamage(int DamageIn) throws InterruptedException
    {
	DAMAGE_TAKEN += DamageIn;
	System.out.println(getName() + " has " + (maxHp - DAMAGE_TAKEN) + " hit points left!");
	Thread.sleep(500);
    }

    public boolean SuccessfulHit()
    {
	int dieRoll = misc.generateRandomInt(DIE_SIDES, 1);
	return(dieRoll <= CHANCE_TO_HIT);
    }

    public void currentHP()
    {
	System.out.println(getName() + " has " + (maxHp - DAMAGE_TAKEN) + " hit points left.");
    }

    public void getHealed(int HealValue) throws InterruptedException
    {
	DAMAGE_TAKEN -= HealValue;
	System.out.println(getName() + " healed for " + HealValue + " hit points!");
	Thread.sleep(500);
    }
    
    public boolean isAlive()
    {
	return(DAMAGE_TAKEN < maxHp);
    }

    public void additionalDamage(int damage)
    {
	addDamage = damage;
    }

    
    public int Attack() throws InterruptedException
    {
	int DamageDone = 0;
	if(SuccessfulHit())
	    {
		DamageDone = (misc.generateRandomInt(MAX_DAMAGE, MIN_DAMAGE));
		System.out.println(getName() + " hit for " + DamageDone + " damage");
		Thread.sleep(500);
	    }
	else
	    {
		System.out.println(getName() + " missed!!");
		Thread.sleep(500);
	    }
	return DamageDone;
    }

    public int getNumTurns(int MONSTER_ATTACK_SPEED)
    {
	if(ATTACK_SPEED < MONSTER_ATTACK_SPEED)
	    return 1;
	else
	    return (int)(ATTACK_SPEED/MONSTER_ATTACK_SPEED);
    }
    
    public int getDieSides()
    {
	return DIE_SIDES;
    }

    
    public void isDead() throws InterruptedException
    {
	System.out.println(getName() + " is dead!");
	Thread.sleep(500);
    }	

    
}

    

