package Dungeon_Game;

import java.util.*;

public class SorcererClass extends HeroCharacter
{
    private int NUMBER_OF_SPECIAL_ATTACKS = 2;
    public SorcererClass(String NAME_IN)
    {
	super(NAME_IN, 90, 55, 25, 0.7, 5, 0.3, 0.4);
	//name, hp, max dam, min dam, chance to hit, attack speed, block percentage, chance to use special skill
    }

    public void getHealed() throws InterruptedException
    {
	int HealValue = misc.generateRandomInt(45, 25);
	super.getHealed(HealValue);	
    }

    @Override
    public int Attack() throws InterruptedException
    {
	Scanner scan    = new Scanner(System.in);
	System.out.println("\nIt is your turn! What would you like to do? \n 1 for normal attack. \n 2 for healing spell \n You have " + NUMBER_OF_SPECIAL_ATTACKS + " healing spells left! \n 3 for magic missle.");
				
	int choice      = Integer.parseInt(scan.nextLine());

	int DamageDone  = 0;
	int used_special_attack = 0;
	
	if(super.SuccessfulHit())
	    {
		if(choice == 1)
		    {
		
			DamageDone = misc.generateRandomInt( super.getMaxDamage(), super.getMinDamage() );
			System.out.println( super.getName() + " hit for " + DamageDone + " damage" );
			Thread.sleep(500);
		
		    }

		if(choice == 3)  
		    {
			DamageDone = (misc.generateRandomInt(150, 75));
			System.out.println(super.getName() + " used a magic missle! " + super.getName() + " hit for " + DamageDone + " damage");
			Thread.sleep(500);
		    }
	    }
	else
	    {
		System.out.println(super.getName() + " missed!!");
		Thread.sleep(500);
	    }

	if(choice == 2 && NUMBER_OF_SPECIAL_ATTACKS > 0)
	    getHealed(0);
	    
	if(choice == 2 && NUMBER_OF_SPECIAL_ATTACKS == 0)
	    {
		System.out.println(super.getName() + "is out of mana! " + super.getName() + " has to attack instead!");
		DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
		System.out.println(super.getName() + " hit for " + DamageDone + " dama1ge");
		Thread.sleep(500);
	    }

	if(used_special_attack > 0)
		    {
			NUMBER_OF_SPECIAL_ATTACKS--;
			used_special_attack = 0;
		    }
	    
	return DamageDone;
    }//end

    @Override
    public void resetSpecialAttack()
    {
	NUMBER_OF_SPECIAL_ATTACKS = 2;
    }

    
}
