package Dungeon_Game;

import java.util.*;

public class Skeleton extends Monster
{
    public Skeleton()
    {
	super("Skeleton", 200, 50, 30, 0.8, 3, 0.3, 50, 30);
	//super(name, hp, max dam, min dam, hit chance, attack speed, chance to heal, max heal, min heal
    }
}

