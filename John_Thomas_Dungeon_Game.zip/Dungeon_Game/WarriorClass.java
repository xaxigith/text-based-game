package Dungeon_Game;

import java.util.*;

public class WarriorClass extends HeroCharacter
{
    private int ENCOUNTER_POWERS = 1;
    private int DAILY_POWER      = 1;

    public WarriorClass(String NAME_IN)
    {
	
	super(NAME_IN, 125, 60, 35, 0.8, 4, 0.2, 0.4);
	//name, hp, max damage, min damage, chance to hit, attack speed, block percentage, chance to use special skill	

    }

    

    @Override
    public int Attack() throws InterruptedException
    {
	
	Scanner scan = new Scanner(System.in);
	System.out.println("What attack would you like to do? "
			   + "\n 1 for normal attack."
			   + "\n 2 for encounter attack."
			   + "\n 3 for daily attack.");
	Thread.sleep(500);

	int choice = Integer.parseInt(scan.nextLine());
	
	int used_encounter_power = 0;
	int used_daily_power     = 0;
	int DamageDone           = 0;

	
	if(super.SuccessfulHit())
	    {
		if(choice == 1)
		    {
			DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			System.out.println(super.getName() + " hit for " + DamageDone + " damage");	
		    }

		if(choice == 2 && ENCOUNTER_POWERS > 0)
		    {
			DamageDone = (misc.generateRandomInt(160, 90));
			System.out.println(super.getName() + " hit with a crushing blow! "+ super.getName() + " hit for " + DamageDone + " damage");
			used_encounter_power += 1;
			Thread.sleep(500);		
		    }
		
		if(choice == 2 && ENCOUNTER_POWERS == 0)
		    {
			System.out.println(super.getName() + " is too tired to do a crushing blow! " + super.getName() + " swings instead.");
			DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			System.out.println(super.getName() + " hit for " + DamageDone + " damage");
			Thread.sleep(500);
		    }

		if(choice == 3 && DAILY_POWER > 0)
		    {
			DamageDone = (misc.generateRandomInt(200, 100));
			System.out.println(super.getName() + " hit with a holy blow! " + super.getName() + " hit for " + DamageDone + " damage");
			used_daily_power += 1;
			Thread.sleep(500);		
		    }
		
		if(choice == 3 && DAILY_POWER == 0)
		    {
			System.out.println(super.getName() + " is too tired to do a holy blow! " + super.getName() + " swings instead.");
			DamageDone = (misc.generateRandomInt(super.getMaxDamage(), super.getMinDamage()));
			System.out.println(super.getName() + " hit for " + DamageDone + " damage");

			Thread.sleep(500);
		    }

		if(used_encounter_power > 0)
		    {
			ENCOUNTER_POWERS--;
			used_encounter_power = 0;
		    }
		if(used_daily_power > 0)
		    {
			DAILY_POWER--;
			used_daily_power = 0;
		    }
	    }
	else
	    {
		System.out.println(super.getName() + " missed!!");
		Thread.sleep(500); 

	    }
	return DamageDone;
    }
    @Override
    public void resetSpecialAttack()
    {
	ENCOUNTER_POWERS = 1;
    }
}//end class
