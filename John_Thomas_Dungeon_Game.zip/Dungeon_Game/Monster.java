package Dungeon_Game;

import java.util.*;

public abstract class Monster extends DungeonCharacter
{
    double CHANCE_TO_HEAL;
    private int CHANCE_TO_HEAL_INT;
    private int MAX_HEAL;
    private int MIN_HEAL;
    private String specialName;
    
    public Monster(String NAME_IN, int HP_IN, int DAM_MAX_IN, int DAM_MIN_IN, double CHANCE_TO_HIT_IN, int ATTACK_SPEED_IN, double CHANCE_TO_HEAL_IN, int MAX_HEAL_IN, int MIN_HEAL_IN)
    {
	super(NAME_IN, HP_IN, DAM_MAX_IN, DAM_MIN_IN, CHANCE_TO_HIT_IN, ATTACK_SPEED_IN);
	
	CHANCE_TO_HEAL = CHANCE_TO_HEAL_IN;
	
	CHANCE_TO_HEAL_INT = (int) (super.getDieSides() * CHANCE_TO_HEAL);
	MAX_HEAL = MAX_HEAL_IN;
	MIN_HEAL = MIN_HEAL_IN;
    }

    @Override
    public int Attack() throws InterruptedException
    {
	int dieRoll = misc.generateRandomInt(super.getDieSides(), 1);
	int healValue = 0;
	if(dieRoll <= CHANCE_TO_HEAL_INT)
	    {
		healValue = (misc.generateRandomInt(MAX_HEAL, MIN_HEAL));
		super.getHealed(healValue);
		return 0;
	    }
	else
	    {
		return super.Attack();
	    }
    }


    @Override
    public String getName()
    {
	if(specialName != null)
	    {
		return specialName;
	    }
	else
	    return super.getName();
	
    }
    public void getSpecialName()
    {
	//I want to have a method that gives the monster a unique name.
	int nameInt = misc.generateRandomInt(10, 1);
	switch(nameInt)
	    {
	    case 1:
		specialName = "Rothar";
		break;
	    case 2:
		specialName = "Malir";
		break;
	    case 3:
		specialName = "Wir";
		break;
	    case 4:
		specialName = "Fogiz";
		break;
	    case 5:
		specialName = "Buli";
		break;
	    case 6:
		specialName = "Vega";
		break;
	    case 7:
		specialName = "Aldeberan";
		break;
	    case 8:
		specialName = "Mars";
		break;
	    case 9:
		specialName = "Lord Steve";
		break;
	    case 10:
		specialName = "Brodin";
		break;
		
		
	    }
    }
}
