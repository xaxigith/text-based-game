package Dungeon_Game;

import java.util.*;

public class Dungeon_Main
{

    static HeroCharacter character1;
    static Scanner       scan = new Scanner(System.in);
    static Monster[]     monsterArray = new Monster[12];
    static int           potionInt = 0;
    static Potions[]     potionBag = new Potions[2];
    
    public static void main(String[] args)
    {
	getCharacters();
	getMonsters();
	getPotions();
	monstersAttack();

    }

    public static void getPotions()
    {
	for(int i = 0; i < potionBag.length; i++)
	    {
		int type = misc.generateRandomInt(2, 1);
		switch(type)
		    {
		    case 1:
			potionBag[i] = new Healing_Potion(); //this is a healing potion
			break;
		    case 2:
			potionBag[i] = new Healing_Potion(); //this is a soured healing potion
			((Healing_Potion) potionBag[i]).sour(); //souring the potion
			break;
		    }
	    }
    }

    public static void getCharacters()
    {
	
	System.out.println("What is the name of your character?"); //Getting the name of the hero.
	String name = scan.nextLine();
	
	System.out.println("What class of hero are you?"
			   + "\n Enter 1 for Warrior."
			   + "\n Enter 2 for Sorcerer."
			   + "\n Enter 3 for Thief. "); //asking the class of the character
	
	int choice  = Integer.parseInt(scan.nextLine());

	switch(choice)
	    {
	    case 1:
		character1 = new WarriorClass(name);
		break;
	    case 2:
		character1 = new SorcererClass(name); //making the hero more specific
	        break;
	    case 3:
		character1 = new ThiefClass(name);    //I used a switch so that the code is smaller than ifs
		break;
	    }

	System.out.println("");//wanted a new line printedw
	
    }
    
    public static void getMonsters()
    {
	
	for(int i = 0; i < monsterArray.length; i++)
	    {
		
		int type = misc.generateRandomInt(3, 1); //randomly generate the type of monster
		switch(type) //this switch determines what type of monster it is.
		    {
			
		    case 1:
			monsterArray[i] = new Ogre();
			break;
		    case 2:
			monsterArray[i] = new Skeleton();
			break;
		    case 3:
			monsterArray[i] = new Gremlin();
			break;
			
		    }//end switch
		
	    }//end for

    }
    
    public static void monstersAttack()
    {
	int choice = 0;

	try{
	    for(int q = 0; q < monsterArray.length; q++) //running through the array of monster
		{
		    System.out.println(monsterArray[q].getName()
				       + " attacks " + character1.getName() + "!"); //telling the user what is attacking them.

		    while(character1.isAlive() && monsterArray[q].isAlive()) //while both are alive
			{
			    int number_of_turns = character1.getNumTurns(monsterArray[q].getAttackSpeed());
			    //Determine how many turns the user gets per monster turns. i.e. inititive
			    while(number_of_turns > 0)
				{
				    System.out.println("\nWould you like to use a potion or attack?"
						       + "\nEnter 1 for potion"
						       + "\nEnter 2 for attack.");
				    choice = Integer.parseInt(scan.nextLine());

				    while(choice != 1 && choice != 2) //make sure the user is entering a one or two.
					{
					    System.out.println("Enter either 1 or 2.");
					    choice = Integer.parseInt(scan.nextLine());
					}

				    switch(choice)
					{
					case 1:
					    if(potionInt < 2)
						{
					    potionBag[potionInt].usePotion(character1);
					    potionInt++;
						}
					    else
						{
						    System.out.println(character1.getName() + " has no potions left! They attack instead!");
						    
						 monsterArray[q].takeDamage(character1.Attack());   
						}
					    break;
					case 2:
					    monsterArray[q].takeDamage(character1.Attack());
					    break;   
					}
				    
				    number_of_turns--;//reduce the amount of turns I have

				}//end while
			
			    if(monsterArray[q].isAlive()) //if monster is alive, attack user
				character1.takeDamage(monsterArray[q].Attack());
			    else
				monsterArray[q].isDead(); //if monster is dead, say so
			
			}//end while

		    character1.resetSpecialAttack(); //resetting how many special attacks we have

		    if(character1.isAlive() == false) //check if the character is dead. If they are, print out a death statement.
			{
			    character1.isDead();
			    break;
			}//end if  
		    
		}//end for
	}//end try

	catch(InterruptedException e)
	    {
		//I need to catch this, but I'm not sure what to do with it.
	    }

     
    }//end monstersAttack

}//end class
